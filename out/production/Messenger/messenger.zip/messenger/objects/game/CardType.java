package messenger.objects.game;

public enum CardType {
    REGULAR, ACTION
}
