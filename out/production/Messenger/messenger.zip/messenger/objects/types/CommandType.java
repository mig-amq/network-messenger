package messenger.objects.types;

public enum CommandType {
    NONE, UPDATE_HOLDER, FILE_SEND, GET_ROOM, GET_HOLDER, ADD_USER, REMOVE_USER, DOWNLOAD
}
