package messenger.objects.types;

public enum DataType {
    MESSAGE, COMMAND
}
