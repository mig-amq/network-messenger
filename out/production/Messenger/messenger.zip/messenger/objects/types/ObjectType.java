package messenger.objects.types;

public enum ObjectType {
    HOLDER, MESSAGE, ROOM, FILE, DATA
}
