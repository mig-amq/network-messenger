package messenger.objects.types;

public enum RoomType {
    GROUP, REGULAR, PERSONAL
}
