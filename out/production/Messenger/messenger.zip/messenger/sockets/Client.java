package messenger.sockets;

public class Client {
}
